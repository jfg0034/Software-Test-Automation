//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: TaskTest class. Tests are performed to evaluate requirements

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;

import classes.Task;

import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;


@TestMethodOrder(OrderAnnotation.class)
class TaskTest {

	@Test
	@Order(1)
	@DisplayName("Test to CREATE a new task")
	// Verifies task is correctly created with output verification
	void testCreateTask() {
		Task aTask = new Task("Feed pets", "Fill cats' bowls by 8 a.m., pick up any spills");
		
		// Output verification
		System.out.println("VERIFIES TASK WAS CREATED:");
		aTask.displayTask();
		
		// Assertions
		assertTrue(aTask.getTaskName().equals("Feed pets"));
		assertTrue(aTask.getTaskDescription().equals("Fill cats' bowls by 8 a.m., pick up any spills"));
	}
	
	
	@Test
	@Order(2)
	@DisplayName("Test to verify behavior when TASK NAME is NULL")
	// Verifies that if task name is null, then string "NULL" is set as placeholder
	void testTaskNameIsNull() {
		Task aTask = new Task("", "Fill cats' bowls by 8 a.m., pick up any spills");
		
		// Output verification
		System.out.println("VERIFIES BEHAVIOR WHEN TASK NAME IS LEFT BLANK:");
		aTask.displayTask();
		
		assertTrue(aTask.getTaskName().equals("NULL"));
	}
	
	
	@Test
	@Order(3)
	@DisplayName("Test to verify behavior when TASK NAME is TOO LONG")
	// Verifies that if task name is too long, the string is clipped down to the first 20 characters
	void testTaskNameIsTooLong() {
		Task aTask = new Task("Feed pets: Feed first cat, feed second cat", "Fill cats' bowls by 8 a.m., pick up any spills");
		
		// Output verification
		System.out.println("VERIFIES BEHAVIOR WHEN TASK NAME IS TOO LONG:");
		aTask.displayTask();
		
		assertTrue(aTask.getTaskName().equals("Feed pets: Feed firs"));
	}
	
	
	@Test
	@Order(4)
	@DisplayName("Test to verify behavior when TASK DESCRIPTION is NULL")
	// Verifies that if task description is null, then string "NULL" is set as placeholder
	void testTaskDescriptionIsNull() {
		Task aTask = new Task("Feed pets", "     ");
		
		// Output verification
		System.out.println("VERIFIES BEHAVIOR WHEN TASK DESCRIPTION IS LEFT BLANK:");
		aTask.displayTask();
		
		assertTrue(aTask.getTaskDescription().equals("NULL"));
	}	
	
	
	@Test
	@Order(5)
	@DisplayName("Test to verify behavior when TASK DESCRIPTION is TOO LONG")
	// Verifies that if task description is too long, the string is clipped down to the first 50 characters
	void testTaskDescriptionIsTooLong() {
		Task aTask = new Task("Feed pets", "Fill cats' bowls by 8 a.m., pick up any food spills on the carpet");
		
		// Output verification
		System.out.println("VERIFIES BEHAVIOR WHEN TASK DESCRIPTION IS TOO LONG:");
		aTask.displayTask();
		
		assertTrue(aTask.getTaskDescription().equals("Fill cats' bowls by 8 a.m., pick up any food spill"));
	}
	

	// Test can be used to verify behavior when ID may be too long
	// To test this, the idGen start very close to the highest possible 10-character String 
	@Test
	@Order(6)
	@DisplayName("Test to verify behavior when TASK ID is TOO LONG")
	void testTaskIDTooLong() {
		// New task would exceed highest possible task ID, so object takes "NULL" as placeholder
		Task task = new Task("Feed pets", "Fill cats' bowls by 8 a.m., pick up any spills");
		
		// Output verification
		System.out.println("NEW TASK WOULD EXCEED ID LENGTH, NO INPUT IS PASSED");
		task.displayTask();
		
		assertTrue(task.getTaskID() == "NULL");
	}	

}
