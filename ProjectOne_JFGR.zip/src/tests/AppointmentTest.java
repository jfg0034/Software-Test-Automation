//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: AppointmentTest class. Tests are performed to evaluate requirements


package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import classes.Appointment;


@TestMethodOrder(OrderAnnotation.class)
class AppointmentTest {

	@Test
	@Order(1)
	@DisplayName("Test to verify an appointment object is CREATED correctly")
	// Verifies an appointment is created using the defined constructor in the class
	void testCreateAppt() {
		Appointment anAppt = new Appointment ("08/02/2022 12:00", "Visit doctor office at noon");
		
		// Output verification
		System.out.println("APPOINTMENT CREATED:");
		anAppt.displayAppt();
		
		// Assertions 
		assertTrue(anAppt.getStrApptDate().equals("08/02/2022 12:00"));
		assertTrue(anAppt.getApptDescription().equals("Visit doctor office at noon"));
	}
	
	
	@Test
	@Order(2)
	@DisplayName("Test to verify behavior when APPT DATE IS BEFORE CURRENT DATE")
	// Verifies that the anticipated placeholder is set in place when the input is a date in the past (before current date)
	void testApptDateIsBeforeCurrDate() {
		Appointment appt = new Appointment ("01/02/2002 13:00", "Visit doctor office at noon");
		
		// Output verification
		System.out.println("APPOINTMENT CREATED WITH A DATE BEFORE CURRENT DATE:");
		appt.displayAppt();
		
		// Verifies date has been set to the placeholder "01/01/9999 00:00", so date field is not left null
		assertTrue(appt.getStrApptDate().equals("01/01/9999 00:00"));
	}
	

	@Test
	@Order(3)
	@DisplayName("Test to verify behavior when APPT DATE IS NULL")
	// Verifies that the anticipated placeholder is set in place when input is left blank
	void testApptDateIsNull() {
		Appointment appt = new Appointment ("", "Visit doctor office at noon");
		
		// Output verification
		System.out.println("APPOINTMENT CREATED WITH A NULL DATE:");
		appt.displayAppt();
		
		// Verifies date has been set to the placeholder "01/01/9999 00:00", so date field is not left null
		assertTrue(appt.getStrApptDate().equals("01/01/9999 00:00"));
	}
	
	
	@Test
	@Order(4)
	@DisplayName("Test to verify behavior when APPT DATE HAS AN INVALID FORM")
	// Verifies that the anticipated placeholder is set in place when input is invalid in any other way, such as not following proper date and time format
	void testApptDateIsInvalidForm() {
		Appointment appt = new Appointment ("99/99/99999 0000:0", "Visit doctor office at noon");
		
		// Output verification
		System.out.println("APPOINTMENT CREATED WITH AN INVALID DATE FORMAT:");
		appt.displayAppt();
		
		// Verifies date has been set to the placeholder "01/01/9999 00:00", so date field is not left null. No other value was set
		assertTrue(appt.getStrApptDate().equals("01/01/9999 00:00"));
	}
	

	@Test
	@Order(5)
	@DisplayName("Test to verify behavior when APPT DESCRIPTION IS NULL")
	// Verifies that if description is left blank, a String "NULL" is put in place as placeholder
	void testApptDescriptionNull() {
		Appointment appt = new Appointment ("08/02/2022 12:00", null);
		
		// Output verification
		System.out.println("APPOINTMENT CREATED WITH A NULL DESCRIPTION:");
		appt.displayAppt();
		
		// Verifies "NULL" is the assigned String to the field when a null input is provided
		assertTrue(appt.getApptDescription().equals("NULL"));
	}
	
	
	@Test
	@Order(6)
	@DisplayName("Test to verify behavior when APPT DESCRIPTION IS TOO LONG")
	// Verifies that if description has over 50 characters, then only its first 50 characters would be assigned to the field
	void testApptDescriptionTooLong() {
		Appointment appt = new Appointment ("08/02/2022 12:00", "Visit doctor office at noon on 134 Main St. Do not forget to bring test results");
		
		// Output verification
		System.out.println("APPOINTMENT CREATED WITH A DESCRIPTION TOO LONG:");
		appt.displayAppt();
		
		// Verifies the long String is trimmed to its first 50 characters
		assertTrue(appt.getApptDescription().equals("Visit doctor office at noon on 134 Main St. Do not"));
	}
	
	
	// Test can be used to verify behavior when ID may be too long
	// To test this, the idGen start very close to the highest possible 10-character String 
	@Test
	@Order(7)
	@DisplayName("Test to verify behavior when APPT ID is TOO LONG")
	void testTaskIDTooLong() {
		// New appt would exceed highest possible task ID, so object takes "NULL" as placeholder
		Appointment anAppt = new Appointment ("08/02/2022 12:00", "Visit doctor office at noon");
		
		// Output verification
		System.out.println("NEW APPT WOULD EXCEED ID LENGTH, NO INPUT IS PASSED. APPT ID WILL ALWAYS BE LESS THAN 10 CHARACTERS");
		anAppt.displayAppt();
		
		assertTrue(anAppt.getApptID() == "NULL");
	}	

}
