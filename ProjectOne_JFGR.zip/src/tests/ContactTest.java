//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: ContactTest class. Tests are performed to evaluate requirements

package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

import classes.Contact;


@TestMethodOrder(OrderAnnotation.class)
class ContactTest {

	@Test
	@Order(1)
	@DisplayName("Test to CREATE a contact")
	// Test to create a contact, uses a constructor that automatically creates an contactID and uses input to update values
	void testContact() {
		Contact contact = new Contact("Peter", "Stevens", "5552341234", "123 Main St.");
		
		// Output verification:
		System.out.println("VERIFIES CONTACT IS CREATED:");
		contact.displayContact();
		
		// Assertions
		assertTrue(contact.getFirstName().equals("Peter"));
		assertTrue(contact.getLastName().equals("Stevens"));
		assertTrue(contact.getPhone().equals("5552341234"));
		assertTrue(contact.getAddress().equals("123 Main St."));
	}

	
	@Test
	@Order(2)
	@DisplayName("Test to verify behavior when NAME is TOO LONG")
	// Verifies input is modified if length of characters is too long
	void testFirstNameTooLong() {
		Contact contact = new Contact("PeterPeterss", "Stevens", "5552341234", "123 Main St.");
		
		// Output verification:
		System.out.println("NAME WAS TOO LONG:");
		contact.displayContact();
		
		assertTrue(contact.getFirstName().equals("PeterPeter"));
	}
	
	
	@Test
	@Order(3)
	@DisplayName("Test to verify behavior when FIRST NAME is NULL")
	// Verifies input uses string "NULL" in case firstName field is left blank
	void testFirstNameNull() {
		Contact contact = new Contact(null, "Stevens", "5552341234", "123 Main St.");
		
		// Output verification:
		System.out.println("FIRST NAME WAS EMPTY:");
		contact.displayContact();		
		
		assertTrue(contact.getFirstName().equals("NULL"));
	}
	
	
	@Test
	@Order(4)
	@DisplayName("Test to verify behavior when LAST NAME is TOO LONG")
	// Verifies input is modified if length of characters is too long
	void testLastNameTooLong() {
		Contact contact = new Contact("Peter", "StevensStevens", "5552341234", "123 Main St.");
		
		// Output verification:
		System.out.println("LAST NAME WAS TOO LONG:");
		contact.displayContact();
		
		assertTrue(contact.getLastName().equals("StevensSte"));
	}
	
	
	@Test
	@Order(5)
	@DisplayName("Test to verify behavior when LAST NAME is NULL")
	// Verifies input uses string "NULL" in case lastName field is left blank
	void testLastNameNull() {
		Contact contact = new Contact("Peter", "", "5552341234", "123 Main St.");
		
		// Output verification:
		System.out.println("LAST NAME WAS EMPTY:");
		contact.displayContact();
		
		assertTrue(contact.getLastName().equals("NULL"));
	}
	
	
	@Test
	@Order(6)
	@DisplayName("Test to verify behavior when PHONE is NOT 10 DIGITS")
	// Verifies input uses placeholder "5555555555" when phone number is not exactly 10 digits
	void testPhoneNotExactlyTenDigits() {
		Contact contact = new Contact("Peter", "Stevens", "55523412342", "123 Main St.");
		
		// Output verification:
		System.out.println("PHONE WAS NOT EXACTLY 10 DIGITS:");
		contact.displayContact();
		
		assertTrue(contact.getPhone().equals("5555555555"));
	}
	
	
	@Test
	@Order(7)
	@DisplayName("Test to verify behavior when PHONE is NULL")
	// Verifies input uses placeholder "5555555555" when phone number is left blank 
	void testPhoneNull() {
		Contact contact = new Contact("Peter", "Stevens", "          ", "123 Main St.");
		
		// Output verification:
		System.out.println("PHONE WAS EMPTY:");
		contact.displayContact();
		
		assertTrue(contact.getPhone().equals("5555555555"));
	}
	
	
	@Test
	@Order(8)
	@DisplayName("Test to verify behavior when PHONE is NOT ONLY DIGITS")
	// Verifies input uses placeholder "5555555555" when phone number is not entirely formed by digits
	void testPhoneHasOnlyDigits() {
		Contact contact = new Contact("Peter", "Stevens", "N5523412342", "123 Main St.");
		
		// Output verification:
		System.out.println("PHONE WAS NOT ONLY DIGITS:");
		contact.displayContact();
		
		assertTrue(contact.getPhone().equals("5555555555"));
	}
	
	
	@Test
	@Order(9)
	@DisplayName("Test to verify behavior when ADDRESS is TOO LONG")
	// Verifies input is modified if length of characters is too long
	void testAddressTooLong() {
		Contact contact = new Contact("Peter", "Stevens", "5552341234", "123 Main Street, Apartment 5, Florida, USA");
		
		// Output verification:
		System.out.println("ADDRESS WAS TOO LONG:");
		contact.displayContact();
		
		assertTrue(contact.getAddress().equals("123 Main Street, Apartment 5, "));
	}
	
	
	@Test
	@Order(10)
	@DisplayName("Test to verify behavior when ADDRESS is NULL")
	// Verifies input uses string "NULL" in case ADDRESS field is left blank
	void testAddressNull() {
		Contact contact = new Contact("Peter", "Stevens", "5552341234", "    ");
		
		// Output verification:
		System.out.println("ADDRESS WAS EMPTY:");
		contact.displayContact();
		
		assertTrue(contact.getAddress().equals("NULL"));
	}
	
	
	// Test can be used to verify behavior when ID may be too long
	// To test this, the idGen start very close to the highest possible 10-character String 
	@Test
	@Order(11)
	@DisplayName("Test to verify behavior when contactID is TOO LONG")
	void testContactIDTooLong() {
		Contact contact = new Contact("Peter", "Stevens", "5552341234", "123 Main St.");
		
		// Output verification
		System.out.println("NEW CONTACT WOULD EXCEED ID LENGTH, NO INPUT IS PASSED");
		contact.displayContact();
		
		assertTrue(contact.getContactID() == "NULL");
	}	
	
	
	
	

}
