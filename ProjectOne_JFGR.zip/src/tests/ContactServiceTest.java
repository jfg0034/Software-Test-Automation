//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: ContactServiceTest class. Tests are performed to evaluate requirements

package tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

import classes.ContactService;

// Uses MethodOrder annotation to ensure tests are created in order so contactID is inferred for testing purposes
@TestMethodOrder(OrderAnnotation.class)
class ContactServiceTest {

	@Test
	@DisplayName("Test to ADD new contact")
	@Order(1)
	// Verifies a contact is added to the contact list, assertions verify that each field for the first element has been updated correctly
	void addContactTest() {
		ContactService myContacts = new ContactService();
		myContacts.addContact("Peter", "Stevens", "5552341234", "123 Main St.");
		// Output verification
		System.out.println("Contact list with contact added:");
		myContacts.displayList();
		// Assertions
		assertTrue(myContacts.getContact("9999999990").getFirstName().equals("Peter"));
		assertTrue(myContacts.getContact("9999999990").getLastName().equals("Stevens"));
		assertTrue(myContacts.getContact("9999999990").getPhone().equals("5552341234"));
		assertTrue(myContacts.getContact("9999999990").getAddress().equals("123 Main St."));
	}
	
	
	@Test
	@DisplayName("Test to DELETE a contact")
	@Order(2)
	// Verifies a contact with ID "1" is deleted, output verification is shown before and after the deletion
	void deleteContactTest() {
		ContactService myContacts = new ContactService();
		// Add more contacts to the list for visualization purposes
		myContacts.addContact("Mary", "Stevens", "5234341234", "123 Main St.");
		myContacts.addContact("Kathy", "Rogers", "5114341211", "122 River St.");
		myContacts.addContact("Robert", "Daniels", "7773334412", "222 Madison Ave.");
		
		// Output verification
		System.out.println("Contact list before deleting a contact:\n");
		myContacts.displayList();
		
		// Delete contact
		myContacts.deleteContact("9999999991");
		
		// Output verification
		System.out.println("Contact list after deleting a contact with ID 9999999991:\n");
		myContacts.displayList();
		
		assertTrue(myContacts.getContact("9999999991") == null); // getContact will display an error message because no contact exists with such ID
	}
	
	
	@Test
	@DisplayName("Test to UPDATE FIRST NAME of a contact")
	@Order(3)
	// Verifies first name of a contact is updated by searching it through its ID
	void updateFirstNameTest() {
		ContactService myContacts = new ContactService();
		
		// Output verification
		System.out.println("CONTACT OF ID \"9999999990\" BEFORE UPDATE:");
		myContacts.getContact("9999999990").displayContact();
		
		// Update first name
		myContacts.updateFirstName("9999999990", "Lucas");
		
		// Output verification
		System.out.println("CONTACT AFTER FIRST NAME UPDATE:");
		myContacts.getContact("9999999990").displayContact();
		
		assertTrue(myContacts.getContact("9999999990").getFirstName().equals("Lucas"));	
	}
	
	
	@Test
	@DisplayName("Test to UPDATE LAST NAME of a contact")
	@Order(4)
	// Verifies last name of a contact is updated by searching it through its ID
	void updateLastNameTest() {
		ContactService myContacts = new ContactService();
		
		// Output verification
		System.out.println("CONTACT OF ID \"9999999992\" BEFORE UPDATE:");
		myContacts.getContact("9999999992").displayContact();
		
		// Update last name
		myContacts.updateLastName("9999999992", "Collins");
		
		// Output verification
		System.out.println("CONTACT AFTER LAST NAME UPDATE:");
		myContacts.getContact("9999999992").displayContact();
		
		assertTrue(myContacts.getContact("9999999992").getLastName().equals("Collins"));
	}
	
	
	@Test
	@DisplayName("Test to UPDATE PHONE of a contact")
	@Order(5)
	// Verifies phone of a contact is updated by searching it through its ID
	void updatePhoneTest() {
		ContactService myContacts = new ContactService();

		// Output verification
		System.out.println("CONTACT OF ID \"9999999993\" BEFORE UPDATE:");
		myContacts.getContact("9999999993").displayContact();
		
		// Update phone
		myContacts.updatePhone("9999999993", "9898989777");
		
		// Output verification
		System.out.println("CONTACT AFTER PHONE UPDATE:");
		myContacts.getContact("9999999993").displayContact();
		
		assertTrue(myContacts.getContact("9999999993").getPhone().equals("9898989777"));
	}
	
	
	@Test
	@DisplayName("Test to UPDATE ADDRESS of a contact")
	@Order(6)
	// Verifies address of a contact is updated by searching it through its ID
	void updateAddressTest() {
		ContactService myContacts = new ContactService();

		// Output verification
		System.out.println("CONTACT OF ID \"9999999992\" BEFORE UPDATE:");
		myContacts.getContact("9999999992").displayContact();
		
		// Update address
		myContacts.updateAddress("9999999992", "34 Moon Valley St.");
		
		// Output verification
		System.out.println("CONTACT AFTER ADDRESS UPDATE:");
		myContacts.getContact("9999999992").displayContact();
		
		assertTrue(myContacts.getContact("9999999992").getAddress().equals("34 Moon Valley St."));
	}
	
	
	@Test
	@DisplayName("Test to VERIFY CONTACT IS NOT ADDED WHEM CONTACT ID REACHES ITS LIMIT")
	@Order(7)
	// Verifies that a contact is not added to the list after maximum ID has been reached
	void avoidAddingContactTest() {
		ContactService myContacts = new ContactService();
		
		// Add more contacts until the highest possible ID of 10 characters has been reached
		myContacts.addContact("Ruben", "Sans", "3373334442", "11 First St.");	// 9999999994
		myContacts.addContact("Luke", "Jakson", "5322334442", "12 Second St.");	// 9999999995
		myContacts.addContact("Mark", "Whit", "337222442", "13 Third St.");		// 9999999996
		myContacts.addContact("Byron", "Lowe", "6673334442", "14 Fourth St.");	// 9999999997
		myContacts.addContact("Adam", "Sanders", "1373334112", "15 Fifth St.");	// 9999999998
		myContacts.addContact("Ellie", "Wilson", "2273334442", "16 Sixth St.");	// 9999999999
		
		// Add an extra contact that would exceed the highest ID
		myContacts.addContact("Sarah", "Meyer", "3373334442", "17 Seventh St.");// 10000000000 -> TOO LONG, class automatically sets ID to "NULL", but will not be added to the list	
		
		// Output verification
		myContacts.displayList();
		
		assertTrue(myContacts.getContact("-1") == null);
	}
	
}
