//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: TaskServiceTest class. Tests are performed to evaluate requirements


package tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;

import classes.TaskService;


//Uses MethodOrder annotation to ensure tests are created in order so TASK_ID is inferred for testing purposes
@TestMethodOrder(OrderAnnotation.class)
class TaskServiceTest {

	@Test
	@DisplayName("Test to ADD new task")
	@Order(1)
	// Verifies that task was correctly added to the task list
	void testAddTask() {
		TaskService theTasks = new TaskService();
		
		theTasks.addTask("Feed pets", "Feed both cats and dog by 8 a.m.");

		// Output verification
		System.out.println("List of tasks with contact added:");
		theTasks.displayTaskList();
		
		assertTrue(theTasks.getTask("9999999995").getTaskName().equals("Feed pets"));
		assertTrue(theTasks.getTask("9999999995").getTaskDescription().equals("Feed both cats and dog by 8 a.m."));
	}
	
	
	@Test
	@DisplayName("Test to delete a task")
	@Order(2)
	// Verifies that a task is deleted by searching it by its ID, output verification is displayed before and after deletion
	void testDeleteTask() {
		TaskService theTasks = new TaskService();
		
		// Add extra tasks for better visualization
		theTasks.addTask("Clean windows", "Use window cleaner located under the sink by 10 a.m.");
		theTasks.addTask("Get groceries", "List of groceries is attached to the fridge door");
		
		// Output before deletion
		System.out.println("List of tasks before deleting a task:");
		theTasks.displayTaskList();
		
		// Delete task of ID "9999999996"
		theTasks.deleteTask("9999999996");
		
		// Output after deletion
		System.out.println("List of tasks after deleting task with ID \"9999999996\":");
		theTasks.displayTaskList();
		
		assertTrue(theTasks.getTask("9999999996") == null);
	}
	
	
	@Test
	@DisplayName("Test to update name of task")
	@Order(3)
	// Verifies name of task is updated by locating task by its ID, output verification is displayed before and after update
	void testUpdateTaskName() {
		TaskService theTasks = new TaskService();

		// Output verification before name update
		System.out.println("TASK OF ID \"9999999995\" BEFORE NAME UPDATE:");
		theTasks.getTask("9999999995").displayTask();
		
		// Updates task name of ID "9999999995"
		theTasks.updateTaskName("9999999995", "Feed animals");
		
		// Output verification after name update
		System.out.println("TASK OF ID \"9999999995\" AFTER NAME UPDATE:");
		theTasks.getTask("9999999995").displayTask();
		
		assertTrue(theTasks.getTask("9999999995").getTaskName() == "Feed animals");
	}
	
	@Test
	@DisplayName("Test to update description of task")
	@Order(4)
	// Verifies description of task is updated by locating task by its ID, output verification is displayed before and after update
	void testUpdateTaskDescription() {
		TaskService theTasks = new TaskService();

		// Output verification before description update
		System.out.println("TASK OF ID \"9999999997\" BEFORE DESCRIPTION UPDATE:");
		theTasks.getTask("9999999997").displayTask();
		
		// Updates task description of ID "999999999y7"
		theTasks.updateTaskDescription("9999999997", "Use money left on green envelope");
		
		// Output verification after description update
		System.out.println("TASK OF ID \"9999999997\" AFTER DESCRIPTION UPDATE:");
		theTasks.getTask("9999999997").displayTask();
		
		assertTrue(theTasks.getTask("9999999997").getTaskDescription() == "Use money left on green envelope");
	}
		
	@Test
	@DisplayName("Test to VERIFY TASK IS NOT ADDED WHEN TASK ID REACHES ITS LIMIT")
	@Order(7)
	// Verifies that a task is not added to the list after maximum ID has been reached
	void avoidAddingTaskTest() {
		TaskService theTasks = new TaskService();
			
		// Add more tasks until the highest possible ID of 10 characters has been reached
		theTasks.addTask("Walk dogs", "Dogs need shoes on");	// 9999999998
		theTasks.addTask("Prepare lunch", "Use ideas from note on fridge");	// 9999999999
			
		// Add an extra task that would exceed the highest ID
		theTasks.addTask("Clean kitchen", "Wipe counters and do dishes");// 10000000000 -> TOO LONG, class automatically sets ID to "NULL", but will not be added to the list	
			
		// Output verification
		theTasks.displayTaskList();
		
		assertTrue(theTasks.getTask("-1") == null);
		
	}

}
