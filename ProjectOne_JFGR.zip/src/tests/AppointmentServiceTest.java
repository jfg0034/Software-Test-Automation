//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: AppointmentServiceTest class. Tests are performed to evaluate requirements


package tests;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import classes.AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;


//Uses MethodOrder annotation to ensure tests are created in order so APPT_ID is inferred for testing purposes
@TestMethodOrder(OrderAnnotation.class)

class AppointmentServiceTest {

	@Test
	@DisplayName("Test to ADD new Appointment")
	@Order(1)
	// Verifies that an appointment object is created and added to the list
	void testAddAppt() {
		AppointmentService appts = new AppointmentService();
		
		// Adds an appointment to the list
		appts.addAppt("08/02/2022 12:00", "Visit doctor office at noon");
		
		// Output verification
		appts.displayApptList();
		
		// Verifies all fields are correct
		assertTrue(appts.getAppt("9999999994").getStrApptDate().equals("08/02/2022 12:00"));
		assertTrue(appts.getAppt("9999999994").getApptDescription().equals("Visit doctor office at noon"));
	}
	
	
	@Test
	@DisplayName("Test to DELETE an Appointment")
	@Order(2)
	// Verifies that an appointment does not exist on the list after it has been deleted
	void testDeleteAppt() {
		AppointmentService appts = new AppointmentService();
		
		// Add extra appointments for better visualization
		appts.addAppt("07/05/2022 09:00", "Job interview at the courthouse");
		appts.addAppt("09/15/2022 14:30", "Renew driver's license");
		
		// Output verification before deletion
		System.out.println("BEFORE DELETING APPOINTMENT:");
		appts.displayApptList();
		
		// Delete appointment
		appts.deleteAppt("9999999995");
		
		// Output verification after deletion
		System.out.println("AFTER DELETING APPT OF ID \"9999999995\"");
		appts.displayApptList();
		
		// Verifies appointment deleted is non-existent
		assertTrue(appts.getAppt("9999999995") == null);
	}
	
	
	/* NO OTHER REQUIREMENTS WERE MADE, SO "UPDATE APPOINTMENT DATE" OR "UPDATE APPOINTMENT DESCRIPTION"
	 * ARE NOT SUPPORTED YET
	 */

}
