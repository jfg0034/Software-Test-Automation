//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: Task class. This class creates a task with a unique ID


package classes;

import java.util.concurrent.atomic.AtomicLong;

public class Task {
	
	private final String TASK_ID;
	private String taskName;
	private String taskDescription;
	private static AtomicLong idGen = new AtomicLong(9999999994L);
	

	
	// Constructor
	public Task (String taskName, String taskDescription) {

		// Verifies TASK_ID does not exceed 10 characters, if so then ID takes a temporary string "NULL", which would be used later to avoid adding a new task
		if (String.valueOf(idGen.incrementAndGet()).length() > 10) {
			this.TASK_ID = "NULL";
			// Sets other fields with placeholders
			setTaskName("NULL");
			setTaskDescription("NULL");
			return;
		}
		else {
			// Generates an ID incremented by one from the previous one so there are no duplicates
			this.TASK_ID = String.valueOf(idGen);
		}
		
		// Updates other fields with input with its own methods
		setTaskName(taskName);
		setTaskDescription(taskDescription);
	}
	
	
	// Private helper function to verify input is not passed null, otherwise string "NULL" is put in place
	private String verifyNull(String something) {
		if (something == null || something.isBlank()) {
			return "NULL";
		}
		else {
			return something;
		}
	}	
	
	
	
	// SETTERS

	// Method to set the name of the task, evaluates length of input so it does not exceed 20 characters
	public void setTaskName (String taskName) {
		taskName = verifyNull(taskName);
		if (taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		}
		else {
			this.taskName = taskName;
		}
	}
	
	// Method to set the description of the task, verifies length of input does not exceed 50 characters
	public void setTaskDescription (String taskDescription) {
		taskDescription = verifyNull(taskDescription);
		if (taskDescription.length() > 50) {
			this.taskDescription = taskDescription.substring(0, 50);
		}
		else {
			this.taskDescription = taskDescription;
		}
	}

	
	// GETTERS
	// All fields can be retrieved
	// Method names and behaviors are self-explanatory
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	public String getTaskID() {
		return TASK_ID;
	}
	

	// Displays the stored values of a task for verification
	public void displayTask() {
		System.out.println("Task ID: " + getTaskID());
		System.out.println("Task Name: " + getTaskName());
		System.out.println("Task Description: " + getTaskDescription() + "\n");
	}

};
