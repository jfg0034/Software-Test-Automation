//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: ContactService class. This class contains a list of contacts, and is able to add new ones, delete and update existing ones


package classes;

import java.util.ArrayList;
import java.util.List;

public class ContactService {
	
	// List is used to store contacts of type Contact
	private static List<Contact> contacts = new ArrayList<Contact>();
	
	
	// Adds a new contact to the list using the constructor
	public void addContact(String firstName, String lastName, String phone, String address) {
		Contact aContact = new Contact(firstName, lastName, phone, address);
		
		// This conditional statement verifies that if a contact is created with an ID of more than 10 characters, it won't add it to the list
		if (aContact.getContactID() == "-1") {
			System.out.println("Cannot add another contact!");
			return;
		}
		contacts.add(aContact);
	}
	
	// Deletes an existing contact, removes it from the list if contact is found by ID
	public void deleteContact(String contactID) {
		contacts.removeIf(n -> n.getContactID().equals(contactID));
	}
	
	// Finds a contact in list by contactID and returns the contact, if no contact is found returns a null contact
	public Contact getContact(String contactID) {
		Contact aContact = null;
		for(Contact contact: contacts) {
			if (contact.getContactID().equals(contactID)) {
				return contact;
			}
		}
		System.out.println("Unable to find contact with ID \"" + contactID + "\".\n");
		return aContact;
	}
	
	// Finds a contact in the list by checking its ID, if found, its firstName field is updated and the methods exits
	// if a contact with such ID does not exist, an error message is displayed
	public void updateFirstName(String contactID, String newFirstName) {
		for(Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				contact.setFirstName(newFirstName);
				return;
			}
		}
		System.out.println("Unable to update first name.");
	}
	
	// Finds a contact by ID and updates its lastName field
	public void updateLastName(String contactID, String newLastName) {
		for(Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				contact.setLastName(newLastName);
				return;
			}
		}
		System.out.println("Unable to update last name.");
	}
	
	// Finds a contact by ID and updates its address
	public void updateAddress(String contactID, String newAddress) {
		for(Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				contact.setAddress(newAddress);
				return;
			}
		}
		System.out.println("Unable to update address.");
	}
	
	// Finds a contact by ID and updates its phone number
	public void updatePhone(String contactID, String newPhone) {
		for(Contact contact : contacts) {
			if (contact.getContactID().equals(contactID)) {
				contact.setPhone(newPhone);
				return;
			}
		}
		System.out.println("Unable to update phone number.");
	}
	
	// Displays the contact list for visualization or verification purposes
	public void displayList() {
		System.out.println("....................................");
		System.out.println("CONTACT LIST");
		System.out.println("....................................");
		for(Contact contact : contacts) {
			contact.displayContact();
		}
		System.out.println("....................................\n");
	}

}