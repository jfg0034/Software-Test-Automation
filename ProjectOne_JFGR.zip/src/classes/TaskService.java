//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: TaskService class. This class contains objects of type Task and is able to modify them


package classes;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	
	// Static list contains objects of type Task, 
	private static List<Task> taskList = new ArrayList<Task>();

	// Method to add a task to the list using the Task constructor
	public void addTask(String taskName, String taskDescription) {
		Task task = new Task(taskName, taskDescription);
		// If task created has an invalid ID (over 10 characters) then it won't be added to the list
		if (task.getTaskID() == "NULL") {
			task = null;
			System.out.println("Cannot add another task!");
			return;
		}
		taskList.add(task);
	}
	
	// Method to delete a task by searching it through its ID
	public void deleteTask(String taskID) {
		taskList.removeIf(n -> n.getTaskID().equals(taskID));
	}
	
	// Method to retrieve a Task by searching it in the list by its ID, if not found an empty task is returned
	public Task getTask(String taskID) {
		Task aTask = null;
		for (Task task : taskList) {
			if (task.getTaskID().equals(taskID)) {
				return task;
			}
		}
		System.out.println("No task of ID \"" + taskID + "\" was found.\n");
		return aTask;
	}
	
	// Method to update the name of a task by searching it by its ID
	public void updateTaskName(String taskID, String newTaskName) {
		for (Task task : taskList) {
			if (task.getTaskID().equals(taskID)) {
				task.setTaskName(newTaskName);
				return;
			}	
		}
		System.out.println("Unable to update Task Name. No task of ID \"" + taskID + "\" was found.");
	}
	
	// Method to update the description of a task by searching it by its ID
	public void updateTaskDescription(String taskID, String newTaskDescription) {
		for (Task task : taskList) {
			if (task.getTaskID().equals(taskID)) {
				task.setTaskDescription(newTaskDescription);
				return;
			}	
		}
		System.out.println("Unable to update Task Description. No task of ID \"" + taskID + "\" was found.");
	}
	
	// Method to display a detailed list of the tasks included in the list
	public void displayTaskList() {
		System.out.println("....................................");
		System.out.println("LIST OF TASKS:");
		System.out.println("....................................");
		for (Task task : taskList) {
			task.displayTask();
		}
		System.out.println("....................................");
	}

}
