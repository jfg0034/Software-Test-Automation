//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: Appointment class. This class creates an appointment with a unique ID


package classes;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Date;
import java.text.SimpleDateFormat;

import java.text.ParseException;


public class Appointment {
	
	private final String APPT_ID;
	private Date apptDate;
	private String apptDescription;
	
	// Variable that will store the current day the object is created for verification purposes
	private Date currentDate;
	// Format to get a date with the form "MM/dd/yyyy HH:mm", for both input and output
	private SimpleDateFormat formatDate = new SimpleDateFormat("MM/dd/yyyy HH:mm");
	// ID generator counter
	private static AtomicLong idGen = new AtomicLong(9999999993L);
	
	
	// CONSTRUCTOR
	
	public Appointment (String apptDate, String apptDescription) {
		// Verifies APPT_ID does not exceed 10 characters, if so then ID takes a temporary string "NULL", which would be used later to avoid adding a new appointment
		if (String.valueOf(idGen.incrementAndGet()).length() > 10) {
			this.APPT_ID = "NULL";
			
			setDate ("01/01/9999 00:00");
			setApptDescription ("NULL");
			return;
		}
		else {
			// Generates an ID incremented by one from the previous one so there are no duplicates
			// because idGen was incremented before, the value assigned to the appt ID will start with "1"
			this.APPT_ID = String.valueOf(idGen);
		}
		
		// Uses class methods to assign values to its fields
		setDate (apptDate);
		setApptDescription (apptDescription);
	}
	
	
	// Private helper function to verify input is not passed null, otherwise string "NULL" is put in place
	private String verifyNull(String something) {
		if (something == null || something.isBlank()) {
			return "NULL";
		}
		else {
			return something;
		}
	}
	
	
	
	// Setters
	
	// Method to set the date of the appointment, input is taken as a String and passed as a Date type
	public void setDate (String apptDateStr) {
		// Establishes the current date the appointment is being set
		currentDate = new Date();
		// Leniency is set false so input strictly takes input with the specified format
		formatDate.setLenient(false);
		
		try {
			// An "apptDate" of type Date is create by parsing the String input with the format date specified
			Date apptDate = formatDate.parse(apptDateStr);
			
			// If input is a date in the future, then the value of "apptDate" is passed to the field of the current object 
			if (currentDate.before(apptDate)) {
				this.apptDate = apptDate;
			}
			// If input is a date in the past, then a placeholder "01/01/9999 00:00" is put in place so the field is not left null
			else {
				this.apptDate = formatDate.parse("01/01/9999 00:00");
			}
		} 
		// If parsing is not possible due to format errors or any other one, the method calls itself with a placeholder as input
		// This placeholder will be passed so the field is not left null
		catch (ParseException e) {
			setDate("01/01/9999 00:00");
		}	
	}
	
	
	// Method to set the Appointment Description
	public void setApptDescription (String apptDescription) {
		// Uses private method to validate input and verify String is not null
		apptDescription = verifyNull(apptDescription);
		
		// Updates apptDescription field (without validating length yet)
		this.apptDescription = apptDescription;
		
		// Only if length is found to be longer than 50 characters, the field is reassigned to a substring of 50 characters
		if (apptDescription.length() > 50) {
			this.apptDescription = apptDescription.substring(0, 50);
		}
	}
	
	
	// Getters
	// All fields can be retrieved
	// Method names and behaviors are self-explanatory
	
	public String getApptID() {
		return APPT_ID;
	}
	
	// Method that returns the field of Date type storing the appointment date
	public Date getApptDate() {
		return apptDate;
	}
	
	// Extra method that returns the date of the appointment as a String, for verification and visualization purposes
	public String getStrApptDate() {
		return formatDate.format(getApptDate());
	}
	
	public String getApptDescription() {
		return apptDescription;
	}

	
	
	// Displays the stored values of an appointment for verification
	public void displayAppt() {
		System.out.println("Appointment ID: " + getApptID());
		System.out.println("Appointment Date: " + getStrApptDate());
		System.out.println("Appointment Description: " + getApptDescription() + "\n");
	}	
}
