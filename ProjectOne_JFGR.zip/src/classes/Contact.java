//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: Contact class. This class creates a contact with a unique ID


package classes;

import java.util.concurrent.atomic.AtomicLong;

public class Contact {
	private final String CONTACT_ID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	private static AtomicLong idGen = new AtomicLong(9999999989L);
	
	// Private helper function to avoid redundancy and shorten code, this function verifies that input is not null or empty
	// otherwise replaces the field with "NULL"
	private String verifyNull(String something) {
		if (something == null || something.trim().isEmpty()) {
			return "NULL";
		}
		else {
			return something;
		}
	}
	
	// CONSTRUCTOR
	public Contact(String firstName, String lastName, String phone, String address) {
		
		// Verifies contactID does not exceed 10 characters
		if (String.valueOf(idGen.incrementAndGet()).length() > 10) {
			this.CONTACT_ID = "NULL";
			// Sets other fields with known placeholders
			setFirstName("NULL");
			setLastName("NULL");
			setPhone("5555555555");
			setAddress("NULL");
			return;
		}
		else {
			// Generates an ID incremented by one from the previous one so there are no duplicates
			this.CONTACT_ID = String.valueOf(idGen);
		}
		
		// Uses its own setter methods to update all remaining fields
		setFirstName(firstName);
		setLastName(lastName);
		setPhone(phone);
		setAddress(address);
	}


	// SETTERS
	// All fields can be updated but the contactID
	
	// Method verifies that there is a non-null input and updates firstName field, note that a string of 11 or more spaces would have length > 10, therefore verifyNull is used
	// If it has over 10 characters, it takes only the first 10
	public void setFirstName (String firstName){
		if (verifyNull(firstName).length() > 10) {
			this.firstName = firstName.substring(0, 10);
		}
		else {
			this.firstName = verifyNull(firstName);
		}
	}
	
	// Method verifies non-null input and updates lastName field
	public void setLastName (String lastName) {
		if (verifyNull(lastName).length() > 10) {
			this.lastName = lastName.substring(0, 10);
		}
		else {
			this.lastName = verifyNull(lastName);
		}
	}
	
	// Method verifies input is not null and is exactly 10 digits only, then updates phone field
	// If input does not satisfy the control, string "5555555555" is put as placeholder
	public void setPhone (String phone) {
		if (phone == null || phone.trim().isEmpty() || phone.length() != 10 || !phone.matches("[0-9]+")) {
			this.phone = "5555555555";
		}
		else {
			this.phone = phone;
		}
	}
	
	
	// Method verifies input is not null and updates address field
	// If address input has more than 30 characters, it will only take the first 30
	public void setAddress (String address) {
		if (verifyNull(address).length() > 30) {
			this.address = address.substring(0, 30);
		}
		else {
			this.address = verifyNull(address);
		}
	}
	
	
	// GETTERS
	// All fields can be retrieved
	// Method names and behaviors are self-explanatory
	
	public String getContactID() {
		return CONTACT_ID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	// Displays the stored values of a contact
	public void displayContact() {
		System.out.println("Contact ID: " + getContactID());
		System.out.println("Contact Full Name: " + getFirstName() + ", " + getLastName());
		System.out.println("Contact Phone: " + getPhone());
		System.out.println("Contact Address: " + getAddress() + "\n");
	}

};