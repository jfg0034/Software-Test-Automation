//Author Name: Joel Gomez

//Date: 06/10/22

//Course ID: CS-230

//Description: AppointmentService class. This class contains objects of type Appointment and is able to add or delete any of its elements


package classes;

import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
	
	// Static list containing objects of type Appointment
	private static List<Appointment> apptList = new ArrayList<Appointment>();
	
	// Method to add an appointment to the list using the Appointment constructor
	public void addAppt(String apptDate, String apptDescription) {
		Appointment appt = new Appointment(apptDate, apptDescription);
		// If appointment created has an invalid ID (over 10 characters) then it won't be added to the list
		if (appt.getApptID() == "NULL") {
			appt = null;
			System.out.println("Cannot add another appointment!");
			return;
		}
		apptList.add(appt);
	}
	
	// Method to delete an appointment by searching it through its ID
	public void deleteAppt(String apptID) {
		apptList.removeIf(n -> n.getApptID().equals(apptID));
	}
	
	
	// Method to retrieve a Task by searching it in the list by its ID, if not found an empty task is returned
	public Appointment getAppt(String apptID) {
		Appointment appt = null;
		for (Appointment anAppt : apptList) {
			if (anAppt.getApptID().equals(apptID)) {
				return anAppt;
			}
		}
		System.out.println("No appointment of ID \"" + apptID + "\" was found.\n");
		return appt;
	}
	
	
	// Method to display a detailed list of the appointments included in the list
	public void displayApptList() {
		System.out.println("....................................");
		System.out.println("LIST OF APPOINTMENTS:");
		System.out.println("....................................");
		for (Appointment appt : apptList) {
			appt.displayAppt();
		}
		System.out.println("....................................");
	}
	
	/* NO OTHER REQUIREMENTS WERE MADE, SO "UPDATE APPOINTMENT DATE" OR "UPDATE APPOINTMENT DESCRIPTION"
	 * IS NOT SUPPORTED YET
	 */

}
